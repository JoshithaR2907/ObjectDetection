# Put all .txt file in here 
*存放每张图片对应的txt文件
